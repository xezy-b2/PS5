#!/bin/bash
# Atelier Coque · retire le pont AMS (arrêt, démarrage automatique, fichiers et réglages)
clear
launchctl bootout "gui/$(id -u)/fr.ateliercoque.pont-ams" >/dev/null 2>&1
rm -f "$HOME/Library/LaunchAgents/fr.ateliercoque.pont-ams.plist"
rm -rf "$HOME/Library/Application Support/AtelierCoque"
rm -f "$HOME/Library/Logs/AtelierCoque-pont-ams.log" "$HOME/.atelier-coque-ams.json"
echo "✓ Pont AMS désinstallé. Rien ne tourne plus en arrière-plan."
read -r -p "Appuie sur Entrée pour fermer… " _
